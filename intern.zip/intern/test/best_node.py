# -*- coding: utf-8 -*-
"""
Created on Wed Jul 29 13:33:29 2020

@author: 2007018
"""
import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
import xlwings as xw
from sklearn.model_selection import train_test_split #to split the dataset for training and testing
from xgboost import XGBRegressor
import xgboost as xgb
from xgboost.sklearn import XGBRegressor
from sklearn import metrics
from scipy import stats

from datetime import datetime, timedelta
import csv
import mysql.connector

def best_node():
    
    wb = xw.Book.caller()
    sht = wb.sheets[1]
    
    mydb = mysql.connector.connect(
      host="TW100103289",       # 数据库主机地址
    #    host="TW100102221",       # 数据库主机地址
      user="root",    # 数据库用户名
      passwd="l5cv0",   # 数据库密码
      database="l5cv0",auth_plugin='mysql_native_password'
    )
    
    Update_daytime=150
    abbrno ='6P'
    
    endtime = datetime.now() - timedelta(days=2/24)
    starttime = datetime.now() - timedelta(days=2/24)- timedelta(days=Update_daytime) 
    Update_time = " AND t.REPORTTIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.REPORTTIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
    
    Sqla =  " select t.REPORTTIME  AS  xml_mea_time,"
    Sqla = Sqla + " t.INFORVALUE22  AS  xml_mea_tool,"
    Sqla = Sqla + " t.INFORVALUE17 AS xml_start_time,"
    #Sqla = Sqla + " t.INFORVALUE10  AS  xml_tool_id,"
    Sqla = Sqla + " t.INFORVALUE5 AS  XML_SHEET_ID,"
    Sqla = Sqla + " t.CHARTID,"
    Sqla = Sqla + " t.MONITORITEMVALUE AS Y"
    Sqla = Sqla + " from l5caryspch_spchis t"
    #Sqla = Sqla + " where t.CHARTID = 'B15H6/PEP1/ADI/AHVA_V1_CD1'"
    Sqla = Sqla + " where 1 = 1"
    Sqla = Sqla + Update_time
    #Sqla = Sqla + " and t.REPORTTIME > '2019-11-20 08:00:00'"
    Sqla = Sqla + " and t.GRAPHTYPE ='X'"
    Sqla = Sqla + " and t.INFORVALUE22 like 'ABMOV%'"
    #Sqla = Sqla + " and t.INFORVALUE10 = 'ABIEXL00'"
    Sqla = Sqla + " and t.INFORVALUE24 ='GL=ADC'"
    Sqla = Sqla + " and t.MONITOR_ITEM_NAME = 'ASVA_V1_CD1_AVE'"
    Sqla = Sqla + " and t.CHARTID like '%1/ADI%1'"
    Sqla = Sqla + " and t.INFORVALUE9 = '" + abbrno + "'"
    
    df = pd.read_sql_query(Sqla, mydb)
    
    df_Y = df[['XML_SHEET_ID',
               'CHARTID',
               'Y']]
    #Update_daytime=1/24
    
    endtime = datetime.now() - timedelta(days=1/24)
    starttime = datetime.now() - timedelta(days=1/24)- timedelta(days=Update_daytime) 
    #Update_time = " AND t.REPORTTIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.REPORTTIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
    Update_time = " AND t.XML_START_TIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.XML_START_TIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
    
    
    Sqla =  " select t.* "
    Sqla = Sqla + " from svm_cd_r2r t"
    Sqla = Sqla + " where 1=1"
    Sqla = Sqla + " and t.XML_OP_ID = 'GL-IEX'"
    Sqla = Sqla + " and t.XML_ABBR_NO = '" + abbrno + "'"
    #Sqla = Sqla + " and t.XML_TOOL_ID = 'ABIEXL10'"
    Sqla = Sqla + Update_time
    
    df = pd.read_sql_query(Sqla, mydb)
    
    df = df.dropna(axis = 0, subset = ['LC_DISPENSQNT',
           'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
           'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
           'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
           'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
           'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
           'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
           'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
           'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
           'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
           'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
           'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
           'LPR', 'SCANSPEED', 'ILLM_AVG'] )
    
    df = df.drop_duplicates('XML_SHEET_ID')
    
    df_X=df[['XML_SHEET_ID','XML_MODEL_NO' ,
           'XML_TOOL_ID','XML_ABBR_NO',
           'LC_DISPENSQNT',
           'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
           'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
           'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
           'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
           'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
           'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
           'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
           'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
           'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
           'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
           'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
           'LPR', 'SCANSPEED', 'ILLM_AVG']]
    
    df = pd.merge(df_Y , df_X, on = 'XML_SHEET_ID', how = 'left')
    
    df = df.dropna(axis = 0, subset = ['LC_DISPENSQNT',
           'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
           'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
           'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
           'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
           'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
           'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
           'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
           'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
           'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
           'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
           'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
           'LPR', 'SCANSPEED', 'ILLM_AVG'] )
    
    df = df.drop_duplicates('XML_SHEET_ID')
    
    df=df[['XML_SHEET_ID','XML_MODEL_NO',
           'XML_TOOL_ID','XML_ABBR_NO','CHARTID',  
           'LC_DISPENSQNT',
           'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
           'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
           'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
           'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
           'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
           'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
           'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
           'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
           'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
           'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
           'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
           'LPR', 'SCANSPEED', 'ILLM_AVG','Y']]
    
    df.to_csv("D:\\xlings_test\\test\\CD_DF.csv")
    df = pd.read_csv("D:\\xlings_test\\test\\CD_DF.csv")
    
    Sqlb = " SELECT distinct (USL + LSL)/2 as 'cd_target' FROM l5caryspchsn_graph WHERE active_flag = 'Y' and graph_type = 'X' and CHART_ID = '" + df.CHARTID[0] + "'" 
    df_cd_target = pd.read_sql_query(Sqlb, mydb)
    
    cd_target = df_cd_target.cd_target[0]
    df = df.drop(['XML_SHEET_ID','XML_MODEL_NO','XML_TOOL_ID','XML_ABBR_NO','CHARTID','Unnamed: 0'],axis=1)
    
    trainy_x = df.drop(['Y'],axis=1)
    trainy_y = df.Y
    
    trainsp_x = df.drop(['SCANSPEED'],axis=1)
    trainsp_y = df.SCANSPEED
    
    X_train, X_test, y_train, y_test = train_test_split(trainy_x, trainy_y, test_size=0.3, random_state=56)
    
    model_y = xgb.XGBRegressor()
    
    eval_set =  [(X_test, y_test)]
    
    model_y.fit(X_train,y_train,early_stopping_rounds=100,eval_metric='mae', eval_set=eval_set,verbose=False)
    
    pred = model_y.predict(X_test)
    
    X_train, X_test, y_train, y_test = train_test_split(trainsp_x, trainsp_y, test_size=0.3, random_state=100)
    
    model_sp = xgb.XGBRegressor()
    
    eval_set =  [(X_test, y_test)]
    
    model_sp.fit(X_train,y_train,early_stopping_rounds=100,eval_metric='mae', eval_set=eval_set,verbose=False)
    
    pred_sp = model_sp.predict(X_test)
    
    trainsp_x.Y = cd_target
    
    pred_new_scp = model_sp.predict(trainsp_x)
    
    best_node = stats.mode(pred_new_scp.astype(np.int))[0][0]
    sht.range('P11').value = best_node
    
    result = []
    i_num = []
    
    for i in range(int(df.SCANSPEED.min()-10),int(df.SCANSPEED.max()+10),1):
        trainy_x.SCANSPEED = i
        pred_new_vd = model_y.predict(trainy_x)
        result.append(np.median(pred_new_vd))
        i_num.append(i)
        
    df_result = pd.DataFrame(list(zip(i_num, result)), columns=['i_num','result'])
    
    for i in range(len(i_num)):
        if df_result.i_num[i] == best_node:
            best_result = df_result.result[i]
        
    plt.plot(i_num,result)
    plt.plot(best_node, best_result, marker='8')
    #best =  plt.annotate(s="best node", xy=(np.median(pred_new_scp),6.307542), xytext=(170, 6.29), 
                    #arrowprops=dict(arrowstyle='->', connectionstyle="arc3,rad=.2"))
    best = plt.annotate(s="best node", xy=(best_node, best_result), xytext=(best_node, best_result+0.003))                 
    fig4 = best.get_figure()
    fig4.set_size_inches(5,5)
    wb.sheets[1].pictures.add(fig4, name='MyPlot4', update=True,
                    left=wb.sheets[1].range('O12').left, top=wb.sheets[0].range('A18').top)        
                  
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

def rmse(predictions, targets):
    return np.sqrt(((predictions - targets) ** 2).mean())