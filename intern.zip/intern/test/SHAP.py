# -*- coding: utf-8 -*-
"""
Created on Mon Aug 17 13:52:42 2020

@author: 2007018
"""

import shap
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

#df = pd.read_csv("D:\\xlings_test\\test\\offline0721.csv")

def SHAP():
    df = pd.read_csv(r'D:\\xlings_test\\test\\CD_DF1.csv')
    df_6P = df.drop(['XML_SHEET_ID', 'XML_MODEL_NO','XML_TOOL_ID','XML_ABBR_NO','CHARTID','Unnamed: 0'],axis=1)
    
    y = df_6P['Y']
    X = df_6P.drop(columns=['Y'])
    train_6P_X, val_6P_X, train_6P_y, val_6P_y = train_test_split(X, y, random_state=1)
    my_model_6P = RandomForestRegressor(max_depth=6, random_state=0, n_estimators=10).fit(train_6P_X, train_6P_y)
    
    row_to_show = 5
    data_for_prediction = val_6P_X.iloc[row_to_show]  # use 1 row of data here. Could use multiple rows if desired
    #data_for_prediction_array = data_for_prediction.values.reshape(1, -1)
    
    # Create object that can calculate shap values
    explainer = shap.TreeExplainer(my_model_6P)
    
    # Calculate Shap values
    shap_values = explainer.shap_values(data_for_prediction)
    
    shap.initjs()
    #shap.force_plot(explainer.expected_value, shap_values, data_for_prediction)
    shap.force_plot(explainer.expected_value, shap_values, data_for_prediction,show=False,matplotlib=True).savefig(r'D:\xlings_test\test\SHAP_6P_1.png', format = "png",dpi = 150,bbox_inches = 'tight')
    # Create object that can calculate shap values
    
    plt.cla()
    plt.clf()
    #explainer = shap.TreeExplainer(my_model_6P)
    
    # calculate shap values. This is what we will plot.
    # Calculate shap_values for all of val_X rather than a single row, to have more data for plot.
    shap_values = explainer.shap_values(val_6P_X)
    
    # Make plot. Index of [1] is explained in text below.
    shap.summary_plot(shap_values, val_6P_X, show=False)
    plt.savefig(r'D:\xlings_test\test\SHAP_6P_2.png', format = "png",dpi = 150,bbox_inches = 'tight')
    
    plt.cla()
    plt.clf()
    shap.summary_plot(shap_values, val_6P_X, plot_type='bar', show=False)
    plt.savefig(r'D:\xlings_test\test\SHAP_6P_3.png', format = "png",dpi = 150,bbox_inches = 'tight')
    
SHAP()