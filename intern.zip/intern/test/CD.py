# -*- coding: utf-8 -*-
"""
Created on Tue Aug 18 09:34:13 2020

@author: 2007018
"""


# coding: utf-8

# In[3]:


import pandas as pd
import seaborn as sns
import xlwings as xw
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler 
from sklearn.linear_model import Lasso
from sklearn.metrics import r2_score
from xgboost import XGBRegressor
from sklearn.linear_model import LinearRegression

from datetime import datetime, timedelta
import mysql.connector

mydb = mysql.connector.connect(
      host="TW100103289",       # 数据库主机地址
      user="root",    # 数据库用户名
      passwd="l5cv0",   # 数据库密码
      database="l5cv0",auth_plugin='mysql_native_password'
    )
    
Update_daytime=150
abbrno ='6P'
    
endtime = datetime.now() - timedelta(days=2/24)
starttime = datetime.now() - timedelta(days=2/24)- timedelta(days=Update_daytime) 
Update_time = " AND t.REPORTTIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.REPORTTIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
    
Sqla =  " select t.REPORTTIME  AS  xml_mea_time,"
Sqla = Sqla + " t.INFORVALUE22  AS  xml_mea_tool,"
Sqla = Sqla + " t.INFORVALUE17 AS xml_start_time,"
#Sqla = Sqla + " t.INFORVALUE10  AS  xml_tool_id,"
Sqla = Sqla + " t.INFORVALUE5 AS  XML_SHEET_ID,"
Sqla = Sqla + " t.CHARTID,"
Sqla = Sqla + " t.MONITORITEMVALUE AS Y"
Sqla = Sqla + " from l5caryspch_spchis t"
#Sqla = Sqla + " where t.CHARTID = 'B15H6/PEP1/ADI/AHVA_V1_CD1'"
Sqla = Sqla + " where 1 = 1"
Sqla = Sqla + Update_time
#Sqla = Sqla + " and t.REPORTTIME > '2019-11-20 08:00:00'"
Sqla = Sqla + " and t.GRAPHTYPE ='X'"
Sqla = Sqla + " and t.INFORVALUE22 like 'ABMOV%'"
#Sqla = Sqla + " and t.INFORVALUE10 = 'ABIEXL00'"
Sqla = Sqla + " and t.INFORVALUE24 ='GL=ADC'"
Sqla = Sqla + " and t.MONITOR_ITEM_NAME = 'ASVA_V1_CD1_AVE'"
Sqla = Sqla + " and t.CHARTID like '%1/ADI%1'"
Sqla = Sqla + " and t.INFORVALUE9 = '" + abbrno + "'"
    
df = pd.read_sql_query(Sqla, mydb)
    
df_Y = df[['XML_SHEET_ID',
               'CHARTID',
               'Y']]
#Update_daytime=1/24
    
endtime = datetime.now() - timedelta(days=1/24)
starttime = datetime.now() - timedelta(days=1/24)- timedelta(days=Update_daytime) 
#Update_time = " AND t.REPORTTIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.REPORTTIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
Update_time = " AND t.XML_START_TIME > '" +'{date:%Y-%m-%d %H:%M:%S}'.format( date=starttime) + "' AND t.XML_START_TIME < '" + '{date:%Y-%m-%d %H:%M:%S}'.format( date=endtime)  + "'"
    
    
Sqla =  " select t.* "
Sqla = Sqla + " from svm_cd_r2r t"
Sqla = Sqla + " where 1=1"
Sqla = Sqla + " and t.XML_OP_ID = 'GL-IEX'"
Sqla = Sqla + " and t.XML_ABBR_NO = '" + abbrno + "'"    
#Sqla = Sqla + " and t.XML_TOOL_ID = 'ABIEXL10'"
Sqla = Sqla + Update_time

df = pd.read_sql_query(Sqla, mydb)

df = df.dropna(axis = 0, subset = ['LC_DISPENSQNT',
       'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
       'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
       'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
       'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
       'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
       'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
       'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
       'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
       'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
       'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
       'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
       'LPR', 'SCANSPEED', 'ILLM_AVG'] )

df = df.drop_duplicates('XML_SHEET_ID')

df_X=df[['XML_SHEET_ID','XML_MODEL_NO' ,
       'XML_TOOL_ID','XML_ABBR_NO',
       'LC_DISPENSQNT',
       'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
       'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
       'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
       'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
       'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
       'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
       'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
       'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
       'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
       'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
       'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
       'LPR', 'SCANSPEED', 'ILLM_AVG']]

df = pd.merge(df_Y , df_X, on = 'XML_SHEET_ID', how = 'left')

df = df.dropna(axis = 0, subset = ['LC_DISPENSQNT',
       'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
       'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
       'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
       'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
       'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
       'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
       'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
       'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
       'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
       'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
       'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
       'LPR', 'SCANSPEED', 'ILLM_AVG'] )

df = df.drop_duplicates('XML_SHEET_ID')

df=df[['XML_SHEET_ID','XML_MODEL_NO',
       'XML_TOOL_ID','XML_ABBR_NO','CHARTID',  
       'LC_DISPENSQNT',
       'LC_DPSSPDSET1', 'LC_DPSSPDSET2', 'LC_DPSSPDSET3', 'LC_NZLSPDMENT',
       'LC_COTPRESS', 'LC_TEMP', 'LC_HUM', 'SHP_TEMP1', 'SHP_TEMP2',
       'SCP_TEMP', 'SB_PROCID', 'SHP_USEDID', 'SCP_USEDID', 'SHP_TEMP3',
       'SHP_TEMP4', 'SHP_TEMP5', 'SHP_TEMP6', 'DV_DEVPRCTM', 'DV_SP1PMPFLW',
       'DV_ENNZL1FLWRT', 'DV_ENNZL2FLWRT', 'DV_SP3PMPFLW', 'DV_CIRPMPFLW',
       'DV_TANKATEMP', 'DV_NRCONCENT1', 'DV_NACONCENT1', 'DV_PMPFLWR1',
       'DV_ENSWFLWRTR1', 'DV_HSPPRSR1', 'DV_PMPFLWR2', 'DV_DWSPFLWRTR2',
       'DV_ARFLWRTUP', 'DV_ARFLWRTLW', 'DV_ENNZL3FLWRT', 'SLOTZFCUS11',
       'SLOTZFCUS21', 'SLOTZFCUS31', 'SLOTZFCUS41', 'LPMAX', 'LPMIN', 'LPAVE',
       'TMPM', 'TMPP', 'HUMM', 'HUMP', 'PRESM', 'PRESP', 'AIRD', 'AIRCLN',
       'AIRCOL1', 'AIRCOL2', 'AIRN2', 'VAC', 'LPILL', 'LPILR', 'LPILA', 'LPL',
       'LPR', 'SCANSPEED', 'ILLM_AVG','Y']]

df.to_csv("D:\\xlings_test\\test\\CD_DF1.csv")
df = pd.read_csv("D:\\xlings_test\\test\\CD_DF1.csv")    

Sqlb = " SELECT distinct (USL + LSL)/2 as 'cd_target' FROM l5caryspchsn_graph WHERE active_flag = 'Y' and graph_type = 'X' and CHART_ID = '" + df.CHARTID[0] + "'" 
df_cd_target = pd.read_sql_query(Sqlb, mydb)

cd_target = df_cd_target.cd_target[0]
df_CD = df.drop(['XML_MODEL_NO','XML_TOOL_ID','XML_ABBR_NO','CHARTID','Unnamed: 0'],axis=1)


#------5.2 創建數據-------#
train_x = df_CD.drop(columns = ['Y']) #特徵(feature)
train_y = df_CD['Y']                #目標(Target)

#------5.3 建立模型-------#
X_train,X_test,y_train,y_test = train_test_split(train_x,train_y,test_size=0.3,random_state=50)
scaler = MinMaxScaler()

for i in X_train.columns:
    if X_train[i].dtype != 'object':
        X_train[i] = scaler.fit_transform(X_train[[i]])
        X_test[i] = scaler.transform(X_test[[i]])    
    
X_train = X_train.drop('XML_SHEET_ID',1)
X_test = X_test.drop('XML_SHEET_ID',1)  

def feature():
    wb = xw.Book.caller()
    sht = wb.sheets[0]
    
    sht.range('B6').value = 'ABIEXL10'
    sht.range('B7').value = '6P'    
    sht.range('B10').value = df_CD['Y'].min()
    sht.range('B11').value = df_CD['Y'].max()
    sht.range('B12').value = df_CD['Y'].mean()
    sht.range('B13').value = df_CD['Y'].std()
    
    ax = sns.distplot(df_CD['Y'])
    fig = ax.get_figure()
    fig.set_size_inches(2.5, 1.8)
    wb.sheets[0].pictures.add(fig, name='MyPlot', update=True,
                  left=wb.sheets[0].range('C10').left, top=wb.sheets[0].range('C10').top)
    
    corrmat_df_CD = df_CD.corr()
    k = 10 #number ofvariables for heatmap
    cols = corrmat_df_CD.nlargest(k, 'Y')['Y'].index
    cm = np.corrcoef(df_CD[cols].values.T)
    sns.set(font_scale=1.25)
    hm = sns.heatmap(cm, cbar=True, annot=True, square=True, fmt='.2f', annot_kws={'size': 10}, 
    yticklabels=cols.values, xticklabels=cols.values)
    fig1 = hm.get_figure()
    fig1.set_size_inches(5.3, 4.8)
    wb.sheets[0].pictures.add(fig1, name='MyPlot1', update=True,
                  left=wb.sheets[0].range('A24').left, top=wb.sheets[0].range('A24').top)
    
    st = pd.DataFrame(data=corrmat_df_CD['Y']) 
    sht.range('K24').value = st.sort_values(by="Y",ascending=False)
    
    
    st_top3 = st.abs().sort_values(by="Y",ascending=False).head(4) 
    sns.set()
    sns_plot_st = sns.pairplot(df_CD[st_top3.index], size = 2.5)
    sns_plot_st.savefig(r'D:\xlings_test\test\pairplot.jpg')

    
    lasso=Lasso(alpha=0.001)
    lasso.fit(X_train,y_train)
    FI_lasso = pd.DataFrame({"Feature Importance":lasso.coef_}, index=X_train.columns)
    sht.range('U24').value = FI_lasso.sort_values("Feature Importance",ascending=False)
    
    lasso_top3 = FI_lasso.abs().sort_values("Feature Importance",ascending=False).head(4)
    sns.set()
    sns_plot_la = sns.pairplot(df_CD[lasso_top3.index], size = 2.5)
    sns_plot_la.savefig(r'D:\xlings_test\test\pairplot2.jpg')
    
    la = FI_lasso[FI_lasso["Feature Importance"]!=0].sort_values("Feature Importance").plot(kind="barh",figsize=(10,15))
    plt.xticks(rotation=90)
    fig2 = la.get_figure()
    fig2.set_size_inches(5, 4.5)
    wb.sheets[0].pictures.add(fig2, name='MyPlot2', update=True,
                  left=wb.sheets[0].range('N24').left, top=wb.sheets[0].range('N24').top)
  
def LR(): 
    wb = xw.Book.caller()
    sht = wb.sheets[1]
    
    linearRegression = LinearRegression().fit(X_train, y_train)
    linearRegression.predict(X_train)
    
    sht.range('K12').value = mae_value(y_test, linearRegression.predict(X_test))
    sht.range('K13').value = mse_value(y_test, linearRegression.predict(X_test))
    sht.range('K14').value = r2_score(y_test, linearRegression.predict(X_test))
    sht.range('K15').value = mape(y_test, linearRegression.predict(X_test))
                
#def lasso():
    #wb = xw.Book.caller()
    #sht = wb.sheets[1]
    
    #lasso=Lasso(alpha=0.001)
    #lasso.fit(X_train,y_train)
    #lasso.predict(X_train)
    #y_train
    #lasso.predict(X_test)
    #y_test

    #sht.range('C7').value = mae_value(lasso.predict(X_test), y_test)
    #sht.range('C8').value = mse_value(lasso.predict(X_test), y_test)
    #sht.range('C9').value = r2_score(lasso.predict(X_test), y_test)
    #sht.range('C10').value = mape(lasso.predict(X_test), y_test)
    
def xgb(): 
    wb = xw.Book.caller()
    sht = wb.sheets[1]
    
    XGB = XGBRegressor()
    XGB.fit(X_train, y_train)
    XGB.predict(X_train)
    y_train
    XGB.predict(X_test)
    y_test
    
    sht.range('L12').value = mae_value(y_test, XGB.predict(X_test))
    sht.range('L13').value = mse_value(y_test, XGB.predict(X_test))
    sht.range('L14').value = r2_score(y_test, XGB.predict(X_test))
    sht.range('L15').value = mape(y_test, XGB.predict(X_test))
        
    
def RF(): 
    wb = xw.Book.caller()
    sht = wb.sheets[1]
    
    RF = RandomForestRegressor()
    RF.fit(X_train, y_train)
    RF.predict(X_train)
    y_train
    RF.predict(X_test)
    y_test
    
    sht.range('M12').value = mae_value(y_test, RF.predict(X_test))
    sht.range('M13').value = mse_value(y_test, RF.predict(X_test))
    sht.range('M14').value = r2_score(y_test, RF.predict(X_test))
    sht.range('M15').value = mape(y_test, RF.predict(X_test))    
    
def mae_value(y_true, y_pred):
    n = len(y_true)
    mae = sum(np.abs(y_true - y_pred))/n
    return mae

def mse_value(y_true, y_pred):
    n = len(y_true)
    mse = sum(np.square(y_true - y_pred))/n
    return mse

def mape(y_true, y_pred): 
    n = len(y_true)
    mape = sum(np.abs((y_true - y_pred)/y_true))/n*100
    return mape
    